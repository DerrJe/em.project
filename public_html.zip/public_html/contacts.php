<?php
    require_once 'connectionDB.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="Style/style.css">
    <script src="scripts.js"></script>
    <meta charset="UTF-8">
    <title>Builders</title>
</head>
<body>
    <center>
		<h2>Наши сотрудники:</h2>
		<input type="text" id="myInput" onkeyup="filter()" placeholder="Поиск по ФИО.." title="Введите имя">
		<form action="contacts.php" method="post">
            <table class="table_dark" id="myTable">
        		<tr>
        			<th>ID:</th>
        			<th>ФИО:</th>
        			<th>Дата рождения:</th>
        			<th>Номер телефона:</th>
        			<th>Id должности:</th>
        		</tr>
        		<?php while ($row = mysqli_fetch_array($result)):?>
        		    <tr>
        		        <td><?php echo $row[0];?></td>
        		        <td><?php echo $row[1];?></td>
        		        <td><?php echo $row[2];?></td>
        		        <td><?php echo $row[3];?></td>
        		        <td><?php echo $row[4];?></td>
        		    </tr>
                <?php endwhile;?>
        	</table>
        	<input class="custom-btn btn-6" type="submit" name="Default" value="Print">
        	<input class="custom-btn btn-6" type="submit" name="ASC" value="Ascending">
        	<input class="custom-btn btn-6" type="submit" name="DESC" value="Descending">
		</form><br>
	<button class="custom-btn btn-6" onclick="sortTable()"><span>Фамилии(А-Я)</span></button>
	<script>
	    function filter() {
          var input, filter, table, tr, td, i, txtValue;
          input = document.getElementById("myInput");
          filter = input.value.toUpperCase();
          table = document.getElementById("myTable");
          tr = table.getElementsByTagName("tr");
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1];
            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            }       
          }
        }
	</script>
	</center>
</body>
</html>