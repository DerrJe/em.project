<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="Style/style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Builders</title>
</head>
<body>
    <div class="div1">
        <h1 class="center">?onstruction ?ompany</h1><br>
        <h2>History of creation</h2><br>
        <h4>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae iste ratione necessitatibus odio, at earum blanditiis asperiores, culpa officiis perferendis doloribus similique eos nisi! Vel aut atque voluptas nihil sunt!
        Vel officia tempore facilis, fugiat reprehenderit fuga nisi repellat laudantium voluptatum animi quod natus porro doloribus nam fugit deleniti minus sint assumenda soluta facere neque debitis placeat! Perspiciatis, ipsum exercitationem.
        Praesentium ad odio debitis deleniti. Suscipit quae adipisci aperiam beatae delectus aut officia reprehenderit incidunt dolores tempora distinctio necessitatibus iusto quibusdam quod fugiat non, rerum nihil officiis obcaecati veritatis mollitia.
        Blanditiis perspiciatis cum officia quo enim ducimus, omnis sit magni ratione in itaque quas at officiis corrupti voluptate dolore odit aspernatur ipsa iste, id nobis expedita, velit modi error? Consequatur!
        Tempora a amet nostrum temporibus minima aperiam voluptatum perspiciatis, vero incidunt est explicabo dolorem voluptatibus suscipit quasi, expedita quis molestias illo, quam non quaerat natus. Eligendi est placeat hic blanditiis.</h4><br>
        <h2>Our successes</h2><br>
        <table width="100%" cellspacing="0" cellpadding="0">
            <tr> 
             <td><img src="https://st.depositphotos.com/1006472/1872/i/950/depositphotos_18726147-stock-photo-construction-worker-with-blueprint.jpg" 
             width="300" height="300"></td>
             <td valign="top">1) Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus explicabo ducimus inventore, illo labore error incidunt distinctio ad ut voluptatem sequi rem et iusto quos cupiditate! Doloremque perspiciatis vel voluptatum!
             Ipsam fugiat a sint at voluptatum ut, provident deserunt debitis nesciunt facilis delectus tenetur optio quasi quae consequuntur reiciendis atque. Nulla corporis eligendi vel harum inventore reiciendis placeat suscipit blanditiis!<br>
             2) Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis aspernatur dolorem autem labore veritatis tempore inventore similique ab perferendis nesciunt deleniti nihil, placeat eveniet corrupti, velit, quos voluptas porro eius.
             Unde, veniam quasi! In ad beatae maiores inventore sit at fuga nisi accusantium maxime sunt voluptatibus id iste, culpa modi facilis odit, reprehenderit nihil saepe rerum soluta numquam eveniet expedita!<br>
             3) Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quasi, veniam? Vitae sapiente harum itaque voluptates rem enim officia. Neque itaque ducimus dolorem similique doloribus accusantium porro laboriosam incidunt quidem placeat.</td>
            </tr>
        </table>
        <h2>Our contact numbers and information about us</h2>
        <h4> Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus dolorem assumenda, iste tempore maxime repellendus culpa porro fugiat facilis officiis omnis voluptatum ratione voluptatibus veniam modi quidem in fuga. Dignissimos?
        Cumque sunt tenetur hic reprehenderit. Obcaecati, rerum atque! <a href="contacts.php">CONTACT NUMBERS</a>, ab quisquam corrupti tempore ratione consectetur iste optio laborum id. Aliquid nihil reprehenderit quod, eveniet enim earum quo neque sequi!</h4>
    </div>

    <div>
        <h2>Our employees </h2><br1>
        <h4>Oleg Masulman Cringe</h4><br>
        <img src="https://s.pfst.net/2013.06/28522478186ed31345feaa11a324c92d4e0198e36c9_b.jpg" class="img1"><br>
        <h4>Vladimir Putin Molodec</h4><br>
        <img src="https://media.fulledu.ru/documents/images/2018.04.13.10/article/5ad108ee39d49817ab1bf224.jpg" class="img1">
    </div>
    <div class="div2">
        <h2>Our finished projects </h2><br1>
        <h4>Atamari Project</h4><br>
        <img src="https://www.onduline.ru/blog/sites/default/files/blog/2020/02/kras_doma_2.jpg" class="img1"><br>
        <h4>Athens Project</h4><br>
        <img src="https://sites.google.com/site/interernoeiskusstvo/_/rsrc/1398885855491/home/krasivye-doma/_2_1_~1.JPG" class="img1">
    </div>
</body>
</html>