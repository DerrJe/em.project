<?php
    if(isset($_POST['ASC'])){
        $asc_query = "select * from `Workers` ORDER BY FIO";
        $result = executeQuery($asc_query);
    }
    
    else if(isset ($_POST['DESC'])){
        $desc_query = "select * from `Workers` ORDER BY FIO DESC";
        $result = executeQuery($desc_query);
    }
    
    else{
        $default_query = "select * from `Workers`";
        $result = executeQuery($default_query);
    }
    
    function executeQuery($query){
        $connect = mysqli_connect('localhost', 'f0642166_Builders', 'wswsws12345', 'f0642166_Builders');
        $result = mysqli_query($connect, $query);
        return $result;
    }
?>